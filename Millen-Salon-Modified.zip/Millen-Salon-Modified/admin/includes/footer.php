<!--footer-->
    <div class="footer">
       <p>&copy; 2024 Millen Hair Salon Admin Panel.</p>
    </div>
        <!--//footer-->