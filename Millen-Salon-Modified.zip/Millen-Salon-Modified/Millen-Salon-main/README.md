This is the Php code for Millen Hair Salon. 
